# ToastiMaintenance

Kleines Paper-Plugin für den Wartungsmodus von ToastiSMP.

## Voraussetzungen
- Paper 1.21.11
- Java 21

## Bauen
Im Projektordner ausführen:

```bash
gradle build
```

Die fertige JAR liegt danach unter `build/libs/ToastiMaintenance-1.0.0.jar`.

## Installation
1. JAR in den `plugins`-Ordner deines Paper-Servers legen.
2. Server starten.
3. Einstellungen in `plugins/ToastiMaintenance/config.yml` anpassen.

## Befehle
- `/maintenance on` – Wartung aktivieren und nicht freigeschaltete Spieler entfernen
- `/maintenance off` – Wartung deaktivieren
- `/maintenance status` – Status anzeigen
- `/maintenance add <Spieler>` – Spieler freischalten
- `/maintenance remove <Spieler>` – Freischaltung entfernen
- `/maintenance list` – Freigeschaltete Spieler anzeigen

Alias: `/wartung`

## Berechtigung
`toastimaintenance.admin` (standardmäßig OP)

Die Freischaltung wird anhand der UUID gespeichert. Der Wartungsstatus bleibt nach einem Neustart erhalten.
