package de.toastismp.maintenance;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class ToastiMaintenance extends JavaPlugin implements Listener, TabExecutor {
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private boolean maintenanceEnabled;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maintenanceEnabled = getConfig().getBoolean("maintenance.enabled", false);

        if (getCommand("maintenance") == null) {
            getLogger().severe("Der Befehl 'maintenance' fehlt in der plugin.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getCommand("maintenance").setExecutor(this);
        getCommand("maintenance").setTabCompleter(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ToastiMaintenance wurde aktiviert.");
    }

    @Override
    public void onDisable() {
        getConfig().set("maintenance.enabled", maintenanceEnabled);
        saveConfig();
    }

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent event) {
        if (!maintenanceEnabled) {
            return;
        }

        Player player = event.getPlayer();
        if (player.hasPermission("toastimaintenance.admin") || isWhitelisted(player.getUniqueId())) {
            return;
        }

        event.disallow(PlayerLoginEvent.Result.KICK_OTHER, createKickMessage());
    }

    private Component createKickMessage() {
        List<String> lines = getConfig().getStringList("maintenance.kick-message");
        if (lines.isEmpty()) {
            return miniMessage.deserialize("<red>Der Server ist gerade in Wartung.");
        }

        return miniMessage.deserialize(String.join("<br>", lines));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("toastimaintenance.admin")) {
            sendMessage(sender, "no-permission");
            return true;
        }

        if (args.length == 0) {
            sendMessage(sender, "usage");
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "on" -> enableMaintenance(sender);
            case "off" -> disableMaintenance(sender);
            case "status" -> sendMessage(sender, maintenanceEnabled ? "status-on" : "status-off");
            case "add" -> {
                if (args.length < 2) {
                    sendMessage(sender, "usage");
                } else {
                    addPlayer(sender, args[1]);
                }
            }
            case "remove" -> {
                if (args.length < 2) {
                    sendMessage(sender, "usage");
                } else {
                    removePlayer(sender, args[1]);
                }
            }
            case "list" -> listPlayers(sender);
            default -> sendMessage(sender, "usage");
        }
        return true;
    }

    private void enableMaintenance(CommandSender sender) {
        if (maintenanceEnabled) {
            sendMessage(sender, "already-enabled");
            return;
        }

        maintenanceEnabled = true;
        getConfig().set("maintenance.enabled", true);
        saveConfig();

        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.hasPermission("toastimaintenance.admin") && !isWhitelisted(online.getUniqueId())) {
                online.kick(createKickMessage());
            }
        }
        sendMessage(sender, "enabled");
    }

    private void disableMaintenance(CommandSender sender) {
        if (!maintenanceEnabled) {
            sendMessage(sender, "already-disabled");
            return;
        }

        maintenanceEnabled = false;
        getConfig().set("maintenance.enabled", false);
        saveConfig();
        sendMessage(sender, "disabled");
    }

    private void addPlayer(CommandSender sender, String name) {
        OfflinePlayer target = findPlayer(name);
        if (target == null || target.getUniqueId() == null) {
            sendMessage(sender, "player-not-found");
            return;
        }

        String path = "whitelist." + target.getUniqueId();
        if (getConfig().contains(path)) {
            sendMessage(sender, "player-exists", "%player%", name);
            return;
        }

        getConfig().set(path, target.getName() == null ? name : target.getName());
        saveConfig();
        sendMessage(sender, "player-added", "%player%", name);
    }

    private void removePlayer(CommandSender sender, String name) {
        OfflinePlayer target = findPlayer(name);
        if (target == null || target.getUniqueId() == null) {
            sendMessage(sender, "player-not-found");
            return;
        }

        String path = "whitelist." + target.getUniqueId();
        if (!getConfig().contains(path)) {
            sendMessage(sender, "player-missing", "%player%", name);
            return;
        }

        getConfig().set(path, null);
        saveConfig();
        sendMessage(sender, "player-removed", "%player%", name);
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }

        for (OfflinePlayer offline : Bukkit.getOfflinePlayers()) {
            if (offline.getName() != null && offline.getName().equalsIgnoreCase(name)) {
                return offline;
            }
        }
        return null;
    }

    private boolean isWhitelisted(UUID uuid) {
        return getConfig().contains("whitelist." + uuid);
    }

    private void listPlayers(CommandSender sender) {
        ConfigurationSection section = getConfig().getConfigurationSection("whitelist");
        if (section == null || section.getKeys(false).isEmpty()) {
            sendMessage(sender, "list-empty");
            return;
        }

        sendMessage(sender, "list-header");
        section.getKeys(false).stream()
                .map(key -> section.getString(key, key))
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .forEach(name -> sender.sendMessage(miniMessage.deserialize("<dark_gray>• <color:#E0AAFF>" + escape(name))));
    }

    private void sendMessage(CommandSender sender, String key, String... replacements) {
        String prefix = getConfig().getString("messages.prefix", "");
        String message = getConfig().getString("messages." + key, "<red>Nachricht fehlt: " + key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            message = message.replace(replacements[i], replacements[i + 1]);
        }
        sender.sendMessage(miniMessage.deserialize(prefix + message));
    }

    private String escape(String input) {
        return input.replace("<", "\\<").replace(">", "\\>");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("toastimaintenance.admin")) {
            return List.of();
        }

        if (args.length == 1) {
            return List.of("on", "off", "status", "add", "remove", "list").stream()
                    .filter(option -> option.startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }

        if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .sorted(Comparator.naturalOrder())
                    .toList();
        }
        return new ArrayList<>();
    }
}
